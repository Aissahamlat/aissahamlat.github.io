---
sidebar_position: 6
tags:
  - skills
keywords: 
  - Federico Tartarini skills
  - thermal comfort
  - human thermal physiology
image: assets/img/website_screenshot.png
description: This page summarises Federico Tartarini's skills
last_update:
  author: Federico Tartarini
---

# Core Skills

## Programming languages

- Python
- JavaScript

## Software

- JetBrain
- LaTeX
- GitHub

## Languages

- Italian
- English

